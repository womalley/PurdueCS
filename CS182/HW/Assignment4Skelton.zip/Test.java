import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;


public class Test {

    int d; // maximum mileage 
    int[] dist;////array of distances - where dist[i] contains the distance between gas station(i) and gas station(i+1)
    ArrayList stops = new ArrayList();

    public void setDist(int[] dist1) {
        this.dist = Arrays.copyOf(dist1, dist1.length);
    }


    public void setD(int d) {
        this.d = d;
    }
    
    // Example recursive function - Calculating n!
    public double factorial(int n) {
      if(n<0) 
          return -1;//invalid input
      
      if(n==0)
          return 1;
      else 
          return n * factorial(n-1);   
    }
    
    public int iterative_fibonacci(int n){//n is the input number to calculate Fibonacci(n)
     //ADD YOUR CODE HERE	
        
    }
    
    public int recursive_fibonacci(int n){//n is the input number to calculate Fibonacci(n)
        //ADD YOUR CODE HERE	
    }
    
    /* Variables: 
    index = starting gas station index
    fuel = mileage that can be covered with existing tank
    stops = stores the indices of the gas stations in a list
    */
    
    public ArrayList recursive_gas_station(int fuel, int index) {
		
	//ADD YOUR CODE HERE	
      return stops;
    }
    
     public void calculate_time(int n){
         
        long start_time = System.nanoTime();
        // insert corresponding function call to measure the total time taken(in milli seconds) with the given input parameter
        recursive_fibonacci(n);
        long end_time = System.nanoTime();
        long recursive_total_time = end_time-start_time; 
        System.out.println(recursive_total_time);
        
        // long start_time = System.nanoTime();
        // iterative_fibonacci(n)
        // long end_time = System.nanoTime();
        // long iterative_total_time = end_time-start_time; 
        
        // variable 'total_time' stores the total time taken(in nano seconds)
        
        
    }
}
