#!/bin/sh

echo "[lab8] test 1"
rm -rf test1
echo "[lab8] compiling..."
gcc test1.c ../myprintf.c ../printinteger.s -o test1 -std=c99
echo "[lab8] running..."
./test1 > test1out.student
echo "[lab8] comparing..."
diff test1out.student test1out

echo "[lab8] test 2"

rm -rf test2
echo "[lab8] compiling..."
gcc test2.c ../myprintf.c ../printinteger.s -o test2 -std=c99
echo "[lab8] running..."
./test2 > test2out.student
echo "[lab8] comparing..."
diff test2out.student test2out

echo "[lab8] End of test. If diff outputs nothing then well done!"
