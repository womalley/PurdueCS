drop table Order_Details;
drop table Products;
drop table Orders;